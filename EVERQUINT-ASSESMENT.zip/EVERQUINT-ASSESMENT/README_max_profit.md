Max Profit Problem


Mr. X has unlimited land.
He can build:

*Theatre (T)
*Pub (P)
*Commercial Park (C)

Only one building at a time is allowed.


Approach

*Used simple loops
*Tried all possible combinations of T, P, and C
*Checked if total build time is within given time
*Calculated remaining time and total earnings
*Selected the combination with maximum profit


How to Run

Open the Python file or Jupyter Notebook

Call the function with time value

