Water Tank Problem
Problem

Given heights of blocks, find how much water is stored between the blocks after rain.

My Approach

For each block:

*Find highest block on the left
*Find highest block on the right

Water stored = min(left_max, right_max) - block_height


Added water only if value is positive

Used simple loops, no advanced data structures.

How to Run HTML Version

*Save file as index.html
*Open it in browser
*Enter block heights

Click Calculate Water

Jupyter Notebook

Used HTML + JavaScript inside notebook

Button click calculates water

Sample Output
Total Water Stored: 18 Units

Conclusion

This solution clearly shows how water trapping logic works using basic programming concepts.
