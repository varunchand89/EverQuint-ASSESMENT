Dataset Used:

*20 Newsgroups Dataset (from sklearn)
*Contains ~18,000 documents across 20 categories


Data Preprocessing:

The following preprocessing steps were applied:

*Removed headers, footers, and quotes from documents
*Cleaned special characters such as newline (\n) and tab (\t)

Stored documents in a Pandas DataFrame with:

*doc_id
*text
*label
*label_name

These steps ensure the text is clean and suitable for embedding and summarization.

Document Search Methodology

Embedding-Based Semantic Search

[note : while converts each document (text) into a numeric vector (embedding) it may take time]

*Used SentenceTransformer (all-MiniLM-L6-v2) to generate document embeddings
*Converted documents into dense vector representations
*Stored embeddings in NumPy arrays for efficient similarity computation

Query Processing

*User query is converted into an embedding
*Cosine similarity is computed between query and document embeddings
*Top K most relevant documents are retrieved
*This approach improves semantic matching compared to keyword-only search.

Document Summarization:

Model Used

*facebook/bart-large-cnn (Hugging Face Transformers)
*Local LLM used instead of paid APIs

Summarization Flow

*Combine top-K retrieved documents
*Truncate text to avoid model context limits
*Generate summary using the summarization pipeline

Summary Length Options

*Short
*Medium
*Long


Why Local LLM Instead of External API?

*Avoided API rate limits and cost constraints
*Ensured reproducibility and offline execution
*Local LLMs are widely used in real-world systems
*Architecture is API-agnostic and can easily be extended to OpenAI, Gemini, or Anthropic APIs

Evaluation Strategy

*Tested the system using manually created queries
*Verified that retrieved documents are relevant to the query topic
*Observed coherence and factual correctness of summaries


Metric Used:

*Hit@5 Accuracy

Definition:

*A retrieval is considered correct if at least one relevant document appears in the top 5 retrieved results for a given query.

Evaluation Method:

*Randomly sampled documents from the dataset
*Used the document’s category (label_name) as the query
*Checked whether a document from the same category appeared in the top 5 results

Project Structure
Document_Search_Summarization/
│
├── document_search_summarization.ipynb
├── README.md

How to Run the Project:


Requirements

import pandas as pd
from sklearn.datasets import fetch_20newsgroups
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline
import tqdm as notebook_tqdm
import numpy as np
from tqdm import tqdm

Steps

*Open VScode
*Open document_search_summarization.ipynb
*Run all cells sequentially
*Modify the query and summary length as needed


Conclusion

This project demonstrates an end-to-end semantic search and summarization pipeline using modern NLP techniques.
The focus was on clean design, modular logic, and practical implementation, making the solution scalable and extensible.
