# Multi-Step Reasoning Agent with Self-Checking

## Overview
This project implements a simple multi-step reasoning agent that solves structured word problems using three internal phases:
1. Planner
2. Executor
3. Verifier

The agent returns only the final answer and a short explanation to the user, while keeping detailed reasoning in metadata.

---

## Architecture

### 1. Planner
- Reads the question
- Generates a simple step-by-step plan

### 2. Executor
- Extracts values from the question
- Performs calculations step by step
- Produces an intermediate answer

### 3. Verifier
- Validates the output
- Checks if the answer is reasonable
- Triggers retry if needed

---

## Technologies Used
- Python 3
- Standard Python libraries only

---

## How to Run

install package *pip install datetime*

* open  jupyter python notebook in VScode
* run each cell(shift+enter)






